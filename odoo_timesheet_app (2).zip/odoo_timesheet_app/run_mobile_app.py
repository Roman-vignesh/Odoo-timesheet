"""
Odoo Timesheets Mobile App - Live Fullstack Server
Serves the mobile web application and handles direct XML-RPC sync with Odoo:
- Project creation & listing
- Task creation & listing
- Timesheet logging (account.analytic.line)
"""

import http.server
import socketserver
import webbrowser
import socket
import os
import sys
import json
import xmlrpc.client
import urllib.parse

PORT = int(os.environ.get('PORT', 5050))
APP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'timesheet_app')

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Default Odoo Credentials (Configured with User Official API Key)
ODOO_CONFIG = {
    'url': 'https://cpc-traders.odoo.com',
    'db': 'cpc-traders',
    'user': 'vign9290@gmail.com',
    'api_key': '3ae008c6f9532a4a2fa6648194fb8f159569fa22',
    'password': '3ae008c6f9532a4a2fa6648194fb8f159569fa22'
}

def get_odoo_connection():
    """Authenticate with Odoo using API Key or Password and return (common, models, uid, error)."""
    try:
        auth_secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')
        common = xmlrpc.client.ServerProxy(f"{ODOO_CONFIG['url']}/xmlrpc/2/common")
        uid = common.authenticate(ODOO_CONFIG['db'], ODOO_CONFIG['user'], auth_secret, {})
        if not uid:
            # Fallback to secondary secret if defined
            alt_secret = ODOO_CONFIG.get('password') if auth_secret == ODOO_CONFIG.get('api_key') else ODOO_CONFIG.get('api_key')
            if alt_secret:
                uid = common.authenticate(ODOO_CONFIG['db'], ODOO_CONFIG['user'], alt_secret, {})
        if not uid:
            return None, None, None, "Invalid Odoo credentials or database."
        models = xmlrpc.client.ServerProxy(f"{ODOO_CONFIG['url']}/xmlrpc/2/object")
        return common, models, uid, None
    except Exception as e:
        return None, None, None, str(e)

def get_local_ip():
    """Detect local LAN IP address so user can test on their mobile phone."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'

class AppServerHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=APP_DIR, **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def send_json_response(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        # Auto-redirect if user accidentally pastes URL into existing path
        if 'http://' in self.path or 'https://' in self.path:
            self.send_response(302)
            self.send_header('Location', '/')
            self.end_headers()
            return

        parsed = urllib.parse.urlparse(self.path)
        clean_path = parsed.path.rstrip('/')

        if clean_path in ['/favicon.ico', '/favicon.png']:
            self.send_response(302)
            self.send_header('Location', '/icon-192.png')
            self.end_headers()
            return

        if clean_path == '/api/odoo/init':
            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 500)
                return

            try:
                db = ODOO_CONFIG['db']
                secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')
                
                # Fetch all active projects
                projects = models.execute_kw(db, uid, secret, 'project.project', 'search_read', [[]], {'fields': ['id', 'name']})
                # Fetch all tasks
                tasks = models.execute_kw(db, uid, secret, 'project.task', 'search_read', [[]], {'fields': ['id', 'name', 'project_id']})
                # Fetch employee
                emps = models.execute_kw(db, uid, secret, 'hr.employee', 'search_read', [[['user_id', '=', uid]]], {'fields': ['id', 'name']})
                emp_id = emps[0]['id'] if emps else False
                emp_name = emps[0]['name'] if emps else ODOO_CONFIG['user']

                self.send_json_response({
                    'status': 'success',
                    'uid': uid,
                    'employee_id': emp_id,
                    'user_name': emp_name,
                    'projects': projects,
                    'tasks': tasks
                })
            except Exception as e:
                self.send_json_response({'status': 'error', 'message': str(e)}, 500)
            return

        elif clean_path == '/api/odoo/history':
            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 500)
                return

            try:
                db = ODOO_CONFIG['db']
                secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')
                lines = models.execute_kw(
                    db, uid, secret,
                    'account.analytic.line',
                    'search_read',
                    [[['user_id', '=', uid]]],
                    {'fields': ['id', 'name', 'unit_amount', 'date', 'project_id', 'task_id'], 'order': 'date desc, id desc', 'limit': 50}
                )
                self.send_json_response({'status': 'success', 'lines': lines})
            except Exception as e:
                self.send_json_response({'status': 'error', 'message': str(e)}, 500)
            return

        elif clean_path.startswith('/api/odoo/'):
            self.send_json_response({'status': 'error', 'message': 'Endpoint not found'}, 404)
            return

        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        clean_path = parsed.path.rstrip('/')
        content_length = int(self.headers.get('Content-Length', 0))
        post_body = self.rfile.read(content_length).decode('utf-8')
        try:
            data = json.loads(post_body) if post_body else {}
        except Exception:
            self.send_json_response({'status': 'error', 'message': 'Invalid JSON body'}, 400)
            return

        # ---------------------------------------------------------
        # 1. CREATE PROJECT IN ODOO
        # ---------------------------------------------------------
        if clean_path == '/api/odoo/project':
            name = (data.get('name') or '').strip()
            if not name:
                self.send_json_response({'status': 'error', 'message': 'Project name is required'}, 400)
                return

            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 500)
                return

            db = ODOO_CONFIG['db']
            secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')

            try:
                # Check if project already exists
                existing = models.execute_kw(db, uid, secret, 'project.project', 'search_read', [[['name', '=', name]]], {'fields': ['id', 'name']})
                if existing:
                    proj_id = existing[0]['id']
                else:
                    proj_id = models.execute_kw(db, uid, secret, 'project.project', 'create', [{'name': name}])
                    print(f"[+] Created Project #{proj_id} '{name}' in Odoo!")

                self.send_json_response({
                    'status': 'success',
                    'id': proj_id,
                    'name': name,
                    'message': f"Project '{name}' successfully created in Odoo (ID #{proj_id})!"
                })
            except Exception as e:
                print(f"[-] Error creating project: {e}")
                self.send_json_response({'status': 'error', 'message': str(e)}, 500)
            return

        # ---------------------------------------------------------
        # 2. CREATE TASK IN ODOO
        # ---------------------------------------------------------
        elif clean_path == '/api/odoo/task':
            tname = (data.get('name') or '').strip()
            project_id = data.get('project_id')
            if not tname:
                self.send_json_response({'status': 'error', 'message': 'Task name is required'}, 400)
                return

            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 500)
                return

            db = ODOO_CONFIG['db']
            secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')

            try:
                # If no project_id or project_id is invalid, resolve or default to project 1
                if not project_id or int(project_id) > 100000:
                    project_id = 1
                else:
                    project_id = int(project_id)

                # Check if task already exists in that project
                existing = models.execute_kw(db, uid, secret, 'project.task', 'search_read', [[['name', '=', tname], ['project_id', '=', project_id]]], {'fields': ['id', 'name']})
                if existing:
                    task_id = existing[0]['id']
                else:
                    task_id = models.execute_kw(db, uid, secret, 'project.task', 'create', [{'name': tname, 'project_id': project_id}])
                    print(f"[+] Created Task #{task_id} '{tname}' under Project #{project_id} in Odoo!")

                self.send_json_response({
                    'status': 'success',
                    'id': task_id,
                    'name': tname,
                    'project_id': project_id,
                    'message': f"Task '{tname}' successfully created in Odoo (ID #{task_id})!"
                })
            except Exception as e:
                print(f"[-] Error creating task: {e}")
                self.send_json_response({'status': 'error', 'message': str(e)}, 500)
            return

        # ---------------------------------------------------------
        # 3. CREATE TIMESHEET IN ODOO (WITH AUTO-PROJECT/TASK CREATION)
        # ---------------------------------------------------------
        elif clean_path == '/api/odoo/timesheet':
            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 500)
                return

            db = ODOO_CONFIG['db']
            secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')

            project_id = data.get('project_id')
            project_name = (data.get('project_name') or 'Internal').strip()
            task_id = data.get('task_id')
            task_name = (data.get('task_name') or '').strip()

            # Smart Project Resolution: If project_id > 100000 (timestamp id) or invalid, find or create in Odoo!
            try:
                real_project_id = None
                if project_id and int(project_id) < 100000:
                    # Check if valid in Odoo
                    chk = models.execute_kw(db, uid, secret, 'project.project', 'search_read', [[['id', '=', int(project_id)]]], {'fields': ['id']})
                    if chk:
                        real_project_id = chk[0]['id']

                if not real_project_id:
                    # Find by name
                    chk = models.execute_kw(db, uid, secret, 'project.project', 'search_read', [[['name', '=', project_name]]], {'fields': ['id', 'name']})
                    if chk:
                        real_project_id = chk[0]['id']
                    else:
                        # Auto-create the project in Odoo!
                        real_project_id = models.execute_kw(db, uid, secret, 'project.project', 'create', [{'name': project_name}])
                        print(f"[+] Auto-created Project #{real_project_id} '{project_name}' in Odoo!")

                # Smart Task Resolution: If task_name provided, find or create under real_project_id
                real_task_id = None
                if task_id and int(task_id) < 100000:
                    t_chk = models.execute_kw(db, uid, secret, 'project.task', 'search_read', [[['id', '=', int(task_id)]]], {'fields': ['id']})
                    if t_chk:
                        real_task_id = t_chk[0]['id']

                if not real_task_id and task_name:
                    t_chk = models.execute_kw(db, uid, secret, 'project.task', 'search_read', [[['name', '=', task_name], ['project_id', '=', real_project_id]]], {'fields': ['id']})
                    if t_chk:
                        real_task_id = t_chk[0]['id']
                    else:
                        # Auto-create task in Odoo!
                        real_task_id = models.execute_kw(db, uid, secret, 'project.task', 'create', [{'name': task_name, 'project_id': real_project_id}])
                        print(f"[+] Auto-created Task #{real_task_id} '{task_name}' in Odoo!")

                # Resolve employee
                emp_id = data.get('employee_id')
                if not emp_id:
                    emps = models.execute_kw(db, uid, secret, 'hr.employee', 'search_read', [[['user_id', '=', uid]]], {'fields': ['id']})
                    if emps:
                        emp_id = emps[0]['id']

                record_vals = {
                    'name': data.get('description') or task_name or 'Timesheet entry',
                    'project_id': real_project_id,
                    'unit_amount': float(data.get('hours', 1.0)),
                    'date': data.get('date') or '2026-10-05',
                    'user_id': uid
                }
                if real_task_id:
                    record_vals['task_id'] = real_task_id
                if emp_id:
                    record_vals['employee_id'] = int(emp_id)

                new_line_id = models.execute_kw(db, uid, secret, 'account.analytic.line', 'create', [record_vals])
                print(f"[+] Created Odoo Timesheet #{new_line_id}: Project #{real_project_id}, Task #{real_task_id}, Hours: {record_vals['unit_amount']}")

                self.send_json_response({
                    'status': 'success',
                    'id': new_line_id,
                    'project_id': real_project_id,
                    'task_id': real_task_id,
                    'message': f'Timesheet #{new_line_id} successfully logged into Odoo!'
                })
            except Exception as e:
                print(f"[-] Odoo Timesheet Create Error: {e}")
                self.send_json_response({'status': 'error', 'message': str(e)}, 500)
            return

        # ---------------------------------------------------------
        # 4. SETTINGS & TEST CONNECTION
        # ---------------------------------------------------------
        elif clean_path in ['/api/odoo/settings', '/api/odoo/test']:
            if 'url' in data and data['url']: ODOO_CONFIG['url'] = data['url'].rstrip('/')
            if 'db' in data and data['db']: ODOO_CONFIG['db'] = data['db']
            if 'user' in data and data['user']: ODOO_CONFIG['user'] = data['user']
            if 'apiKey' in data and data['apiKey']:
                ODOO_CONFIG['api_key'] = data['apiKey']
                ODOO_CONFIG['password'] = data['apiKey']

            _, models, uid, err = get_odoo_connection()
            if err:
                self.send_json_response({'status': 'error', 'message': err}, 400)
            else:
                db = ODOO_CONFIG['db']
                secret = ODOO_CONFIG.get('api_key') or ODOO_CONFIG.get('password')
                projs = models.execute_kw(db, uid, secret, 'project.project', 'search_read', [[]], {'fields': ['id', 'name']})
                self.send_json_response({
                    'status': 'success',
                    'uid': uid,
                    'projects_count': len(projs),
                    'projects': projs,
                    'message': f'Successfully connected to Odoo! Found {len(projs)} projects.'
                })
            return

        super().do_POST()

def main():
    os.chdir(APP_DIR)
    local_ip = get_local_ip()
    local_url = f"http://localhost:{PORT}"
    mobile_url = f"http://{local_ip}:{PORT}"

    print("=" * 60)
    print("   [+] ODOO MOBILE TIMESHEET APP (LIVE ODOO SYNC)")
    print("=" * 60)
    print(f"* Connected to Odoo   : {ODOO_CONFIG['url']} ({ODOO_CONFIG['db']})")
    print(f"* Laptop / PC URL     : {local_url}")
    print(f"* Mobile Phone (Wi-Fi): {mobile_url}")
    print("\nTip: In mobile Chrome, tap 'Add to Home Screen' to install as app!")
    print("Press Ctrl+C to stop.\n" + "=" * 60)

    try:
        webbrowser.open(local_url)
    except Exception:
        pass

    try:
        with http.server.ThreadingHTTPServer(("", PORT), AppServerHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
        sys.exit(0)

if __name__ == '__main__':
    main()
