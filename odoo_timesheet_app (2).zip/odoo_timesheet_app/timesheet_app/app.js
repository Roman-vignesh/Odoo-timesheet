/**
 * Odoo Timesheets Mobile - Full Realtime Odoo Integration
 * - Creates Projects in Odoo (`project.project`)
 * - Creates Tasks in Odoo (`project.task`)
 * - Logs Timesheets in Odoo (`account.analytic.line`)
 */

// Always clear stale mock cache
localStorage.clear();

let state = {
  odooConnected: false,
  odooUser: 'vignesh',
  projects: [],
  tasks: [],
  timesheets: [],
  activeTimer: {
    isRunning: false,
    startTime: null,
    elapsedSeconds: 0,
    intervalId: null,
    projectId: null,
    projectName: '',
    taskName: ''
  },
  currentView: 'viewLog'
};

// =========================================================
// 1. HELPERS
// =========================================================
function getTodayStr() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getYesterdayStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatHoursAndMins(totalHours) {
  const h = Math.floor(totalHours);
  const m = Math.round((totalHours - h) * 60);
  return `${h}h ${String(m).padStart(2, '0')}m`;
}

function parseTimeToDecimal(timeStr) {
  if (!timeStr) return 0;
  timeStr = String(timeStr).trim();
  if (timeStr.includes(':')) {
    const parts = timeStr.split(':');
    const h = parseInt(parts[0], 10) || 0;
    const m = parseInt(parts[1], 10) || 0;
    return h + m / 60;
  }
  return parseFloat(timeStr) || 0;
}

function decimalToTimeStr(decimalHours) {
  const h = Math.floor(decimalHours);
  const m = Math.round((decimalHours - h) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function formatSecondsToHMS(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function playHapticBeep(freq = 600, duration = 0.08) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (e) {}
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function showToast(msg, isError = false) {
  const toast = document.getElementById('toastBubble');
  if (!toast) return;
  toast.textContent = msg;
  toast.style.borderColor = isError ? 'rgba(244, 63, 94, 0.5)' : 'rgba(16, 185, 129, 0.5)';
  toast.style.display = 'flex';
  setTimeout(() => {
    toast.style.display = 'none';
  }, 3200);
}

function loadLocalTimesheets() {
  const saved = localStorage.getItem('odoo_timesheets_v3');
  if (saved) {
    try { return JSON.parse(saved); } catch (e) {}
  }
  return [];
}

function saveLocalTimesheets(entries) {
  localStorage.setItem('odoo_timesheets_v3', JSON.stringify(entries));
}

// =========================================================
// 2. LIVE ODOO DATA FETCH
// =========================================================
async function fetchOdooInitData(showToastMsg = false) {
  const syncIndicator = document.getElementById('syncIndicator');
  const statusModeTag = document.getElementById('statusModeTag');

  try {
    const res = await fetch('/api/odoo/init?t=' + Date.now());
    if (!res.ok) throw new Error('API offline');
    const data = await res.json();

    if (data.status === 'success') {
      state.odooConnected = true;
      state.projects = data.projects || [];
      state.tasks = data.tasks || [];
      state.odooUser = data.user_name || 'vignesh';
      const userPill = document.getElementById('headerUserPill');
      if (userPill) userPill.textContent = '👤 ' + state.odooUser;

      if (syncIndicator) {
        syncIndicator.className = 'sync-dot synced';
        syncIndicator.title = 'Permanent Live Odoo Sync Active';
      }
      if (statusModeTag) {
        statusModeTag.textContent = '☁️ Live Odoo Sync Active';
        statusModeTag.style.color = '#10b981';
      }

      populateProjectDropdown();
      populateTaskDropdown();
      syncFromOdooHistory();

      if (showToastMsg) {
        showToast(`✓ Synced with Odoo (${state.projects.length} projects live)`);
        playHapticBeep(750, 0.1);
      }
    }
  } catch (err) {
    console.warn('Odoo init fallback:', err);
    state.odooConnected = false;
    if (syncIndicator) syncIndicator.className = 'sync-dot';
    if (statusModeTag) statusModeTag.textContent = '💾 Local Mode';
    populateProjectDropdown();
    populateTaskDropdown();
  }
}

async function syncFromOdooHistory() {
  try {
    const res = await fetch('/api/odoo/history');
    if (!res.ok) return;
    const data = await res.json();
    if (data.status === 'success' && Array.isArray(data.lines)) {
      const odooEntries = data.lines.map(line => ({
        id: 'odoo_' + line.id,
        odooId: line.id,
        project: Array.isArray(line.project_id) ? line.project_id[1] : 'Internal',
        projectId: Array.isArray(line.project_id) ? line.project_id[0] : 1,
        task: Array.isArray(line.task_id) ? line.task_id[1] : (line.name || 'General Task'),
        date: line.date,
        hours: line.unit_amount,
        formattedTime: decimalToTimeStr(line.unit_amount),
        description: line.name || '',
        synced: true
      }));

      state.timesheets = odooEntries;
      saveLocalTimesheets(odooEntries);
      renderTimesheets();
    }
  } catch (e) {
    console.log('History sync note:', e);
  }
}

// =========================================================
// 3. UI RENDERING
// =========================================================
function populateProjectDropdown() {
  const select = document.getElementById('selectProject');
  const filter = document.getElementById('filterProject');
  if (!select) return;

  if (!state.projects || state.projects.length === 0) {
    select.innerHTML = '<option value="" disabled selected>⏳ Loading Odoo Projects...</option>';
    const crumb = document.getElementById('crumbProject');
    if (crumb) crumb.textContent = 'Loading...';
    return;
  }

  const currentVal = select.value;
  select.innerHTML = '';

  // Sort projects so latest projects (like Party 1, GSUS STAR SOLUTION) appear at top
  const sortedProjects = [...state.projects].sort((a, b) => (b.id || 0) - (a.id || 0));

  sortedProjects.forEach((p, idx) => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    // Keep previously selected project or default to the first real project
    if (String(p.id) === String(currentVal) || (!currentVal && idx === 0)) {
      opt.selected = true;
    }
    select.appendChild(opt);
  });

  const customOpt = document.createElement('option');
  customOpt.value = '__NEW__';
  customOpt.textContent = '➕ Create New Project in Odoo...';
  select.appendChild(customOpt);

  if (filter) {
    filter.innerHTML = '<option value="ALL">All Projects</option>';
    sortedProjects.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.name;
      opt.textContent = p.name;
      filter.appendChild(opt);
    });
  }

  updateBreadcrumb();
}

function updateBreadcrumb() {
  const select = document.getElementById('selectProject');
  const crumb = document.getElementById('crumbProject');
  if (select && crumb) {
    const selOpt = select.options[select.selectedIndex];
    crumb.textContent = selOpt ? selOpt.textContent : (state.projects[0] ? state.projects[0].name : 'Internal');
  }
}

function populateTaskDropdown() {
  const projectSelect = document.getElementById('selectProject');
  const datalist = document.getElementById('taskPresets');
  if (!datalist || !projectSelect) return;

  const selectedProjectId = parseInt(projectSelect.value, 10);
  datalist.innerHTML = '';

  const relevantTasks = state.tasks.filter(t => {
    if (!t.project_id) return true;
    if (Array.isArray(t.project_id)) return t.project_id[0] === selectedProjectId;
    return t.project_id === selectedProjectId;
  });

  relevantTasks.forEach(t => {
    const opt = document.createElement('option');
    opt.value = t.name;
    datalist.appendChild(opt);
  });
}

function renderTimesheets() {
  const todayStr = getTodayStr();
  const allEntries = state.timesheets;

  const todayEntries = allEntries.filter(e => e.date === todayStr);
  const totalHoursToday = todayEntries.reduce((acc, curr) => acc + (parseFloat(curr.hours) || 0), 0);
  const goalHours = 8.0;
  const pct = Math.min(100, Math.round((totalHoursToday / goalHours) * 100));

  const statTodayHours = document.getElementById('statTodayHours');
  const todayProgressBar = document.getElementById('todayProgressBar');
  const statEntriesCount = document.getElementById('statEntriesCount');

  if (statTodayHours) statTodayHours.textContent = formatHoursAndMins(totalHoursToday);
  if (todayProgressBar) todayProgressBar.style.width = `${pct}%`;
  if (statEntriesCount) {
    statEntriesCount.textContent = `${todayEntries.length} ${todayEntries.length === 1 ? 'entry' : 'entries'} today (${allEntries.length} total)`;
  }

  const recentContainer = document.getElementById('todayEntriesContainer');
  if (recentContainer) {
    if (allEntries.length === 0) {
      recentContainer.innerHTML = `
        <div class="empty-state-box">
          <span class="empty-state-icon">⏱️</span>
          <div class="empty-state-title">No timesheet entries yet</div>
          <div class="empty-state-desc">Select Project, enter Task and Time Spent, then click Save Timesheet.</div>
        </div>
      `;
    } else {
      const displayEntries = allEntries.slice(0, 5);
      recentContainer.innerHTML = displayEntries.map(e => createEntryCardHTML(e)).join('');
      attachEntryCardEvents(recentContainer);
    }
  }

  renderHistoryView();
}

function renderHistoryView() {
  const container = document.getElementById('allHistoryContainer');
  const totalHoursEl = document.getElementById('historyTotalHours');
  const filterSelect = document.getElementById('filterProject');
  const searchInput = document.getElementById('searchHistory');

  if (!container) return;

  const filterVal = filterSelect ? filterSelect.value : 'ALL';
  const searchVal = searchInput ? searchInput.value.toLowerCase().trim() : '';

  let filtered = [...state.timesheets];

  if (filterVal !== 'ALL') {
    filtered = filtered.filter(e => e.project === filterVal);
  }

  if (searchVal) {
    filtered = filtered.filter(e =>
      (e.task && e.task.toLowerCase().includes(searchVal)) ||
      (e.project && e.project.toLowerCase().includes(searchVal)) ||
      (e.description && e.description.toLowerCase().includes(searchVal))
    );
  }

  const allHours = state.timesheets.reduce((acc, curr) => acc + (parseFloat(curr.hours) || 0), 0);
  if (totalHoursEl) totalHoursEl.textContent = `${allHours.toFixed(1)} hrs`;

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state-box">
        <span class="empty-state-icon">📂</span>
        <div class="empty-state-title">No matching timesheet logs</div>
        <div class="empty-state-desc">Try clearing filters or log a new entry.</div>
      </div>
    `;
  } else {
    container.innerHTML = filtered.map(e => createEntryCardHTML(e)).join('');
    attachEntryCardEvents(container);
  }
}

function createEntryCardHTML(entry) {
  const syncBadge = entry.synced || entry.odooId ?
    `<span style="font-size:10px; color:#10b981; font-weight:700; background:rgba(16,185,129,0.12); padding:2px 6px; border-radius:4px;">☁️ Odoo #${entry.odooId || 'Synced'}</span>` :
    `<span style="font-size:10px; color:#f59e0b; font-weight:700; background:rgba(245,158,11,0.12); padding:2px 6px; border-radius:4px;">💾 Local</span>`;

  return `
    <div class="entry-card" data-id="${entry.id}">
      <div class="entry-card-header">
        <div style="display:flex; align-items:center; gap:6px;">
          <span class="entry-project-badge">${escapeHtml(entry.project)}</span>
          ${syncBadge}
        </div>
        <span class="entry-duration-badge">${entry.formattedTime || decimalToTimeStr(entry.hours)}</span>
      </div>
      <div class="entry-task-title">${escapeHtml(entry.task || 'General Task')}</div>
      ${entry.description ? `<div class="entry-desc">${escapeHtml(entry.description)}</div>` : ''}
      <div class="entry-card-footer">
        <span>📅 ${entry.date}</span>
        <button type="button" class="entry-delete-btn" data-delete-id="${entry.id}" title="Delete Entry">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </div>
    </div>
  `;
}

function attachEntryCardEvents(parentEl) {
  parentEl.querySelectorAll('.entry-delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-delete-id');
      deleteEntry(id);
    });
  });
}

function deleteEntry(id) {
  if (confirm('Delete this entry from the list?')) {
    state.timesheets = state.timesheets.filter(e => e.id !== id);
    saveLocalTimesheets(state.timesheets);
    renderTimesheets();
    showToast('Entry removed');
  }
}

// =========================================================
// 4. CREATE PROJECT & TASK IN ODOO
// =========================================================
async function handleCreateOdooProject(projectName) {
  if (!projectName) return null;
  showToast(`Creating Project '${projectName}' in Odoo...`);

  try {
    const res = await fetch('/api/odoo/project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: projectName })
    });
    const data = await res.json();
    if (data.status === 'success') {
      const newProj = { id: data.id, name: data.name };
      // Check if already in state
      if (!state.projects.some(p => p.id === newProj.id)) {
        state.projects.push(newProj);
      }
      populateProjectDropdown();
      const select = document.getElementById('selectProject');
      if (select) select.value = newProj.id;
      updateBreadcrumb();
      populateTaskDropdown();
      showToast(`✓ Project '${data.name}' created in Odoo! (ID #${data.id})`);
      playHapticBeep(800, 0.15);
      return newProj.id;
    } else {
      showToast(`✕ Error: ${data.message}`, true);
    }
  } catch (err) {
    showToast(`✕ Project creation failed: ${err.message}`, true);
  }
  return null;
}

async function handleCreateOdooTask(taskName, projectId) {
  if (!taskName) return null;
  try {
    const res = await fetch('/api/odoo/task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: taskName, project_id: projectId })
    });
    const data = await res.json();
    if (data.status === 'success') {
      const newTask = { id: data.id, name: data.name, project_id: projectId };
      if (!state.tasks.some(t => t.id === newTask.id)) {
        state.tasks.push(newTask);
      }
      populateTaskDropdown();
      return data.id;
    }
  } catch (err) {
    console.warn('Task create note:', err);
  }
  return null;
}

// =========================================================
// 5. SUBMIT TIMESHEET
// =========================================================
async function handleSaveTimesheet() {
  const projectSelect = document.getElementById('selectProject');
  const dateInput = document.getElementById('inputDate');
  const taskInput = document.getElementById('inputTask');
  const timeInput = document.getElementById('inputTimeSpent');
  const activityInput = document.getElementById('inputActivity');
  const saveBtn = document.getElementById('btnSaveTimesheet');

  let projectId = projectSelect ? projectSelect.value : 1;
  const projectOpt = projectSelect ? projectSelect.options[projectSelect.selectedIndex] : null;
  let projectName = projectOpt ? projectOpt.textContent : 'Internal';

  const date = dateInput && dateInput.value ? dateInput.value : getTodayStr();
  const taskName = taskInput && taskInput.value ? taskInput.value.trim() : 'General Activity';
  let timeStr = timeInput && timeInput.value ? timeInput.value.trim() : '01:00';
  const description = activityInput && activityInput.value ? activityInput.value.trim() : '';

  let hours = parseTimeToDecimal(timeStr);
  if (hours <= 0) {
    hours = 1.0;
    timeStr = '01:00';
    if (timeInput) timeInput.value = '01:00';
  }

  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.innerHTML = `<span>⏳ Saving & Syncing to Odoo...</span>`;
  }

  const payload = {
    project_id: projectId !== '__NEW__' ? parseInt(projectId, 10) : null,
    project_name: projectName,
    task_name: taskName,
    date: date,
    hours: hours,
    description: description || taskName
  };

  let odooLineId = null;
  let syncSuccess = false;

  try {
    const res = await fetch('/api/odoo/timesheet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.status === 'success') {
      odooLineId = result.id;
      syncSuccess = true;
      if (result.project_id && !state.projects.some(p => p.id === result.project_id)) {
        state.projects.push({ id: result.project_id, name: projectName });
        populateProjectDropdown();
      }
    } else {
      showToast('✕ Odoo: ' + (result.message || 'Failed'), true);
    }
  } catch (err) {
    console.warn('Network sync failed:', err);
    showToast('✕ Sync failed: ' + err.message, true);
  }

  const newEntry = {
    id: 'entry_' + Date.now(),
    odooId: odooLineId,
    project: projectName,
    projectId: payload.project_id || 1,
    task: taskName,
    date: date,
    hours: hours,
    formattedTime: decimalToTimeStr(hours),
    description: description,
    synced: syncSuccess,
    timestamp: Date.now()
  };

  state.timesheets.unshift(newEntry);
  saveLocalTimesheets(state.timesheets);

  if (taskInput) taskInput.value = '';
  if (activityInput) activityInput.value = '';
  if (timeInput) timeInput.value = '01:00';

  if (saveBtn) {
    saveBtn.disabled = false;
    saveBtn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      <span>Save Timesheet</span>
    `;
  }

  renderTimesheets();
  playHapticBeep(880, 0.15);

  if (syncSuccess) {
    showToast(`✓ Timesheet #${odooLineId} saved directly to Odoo!`);
    syncFromOdooHistory();
  } else {
    showToast(`⚠️ Could not save to Odoo`, true);
  }
}

// Quick increments
function handleTimeChipAdd(minutesToAdd) {
  const timeInput = document.getElementById('inputTimeSpent');
  if (!timeInput) return;
  const currentHours = parseTimeToDecimal(timeInput.value);
  const newHours = currentHours + (minutesToAdd / 60);
  timeInput.value = decimalToTimeStr(newHours);
  playHapticBeep(650, 0.05);
}

function handleTagChipAdd(tag) {
  const textarea = document.getElementById('inputActivity');
  if (!textarea) return;
  let current = textarea.value.trim();
  if (!current.includes(tag)) {
    textarea.value = current ? `${current} ${tag}` : tag;
  }
  textarea.focus();
  playHapticBeep(700, 0.05);
}

// =========================================================
// 6. STOPWATCH & CONTROLS
// =========================================================
function startTimer() {
  if (state.activeTimer.isRunning) return;

  const projectSelect = document.getElementById('selectProject');
  const taskInput = document.getElementById('inputTask');
  const projOpt = projectSelect ? projectSelect.options[projectSelect.selectedIndex] : null;

  state.activeTimer.isRunning = true;
  state.activeTimer.projectId = projectSelect ? projectSelect.value : 1;
  state.activeTimer.projectName = projOpt ? projOpt.textContent : 'Internal';
  state.activeTimer.taskName = taskInput && taskInput.value ? taskInput.value : 'Active Task';
  state.activeTimer.startTime = Date.now() - (state.activeTimer.elapsedSeconds * 1000);

  state.activeTimer.intervalId = setInterval(tickTimer, 1000);

  updateTimerUI();
  playHapticBeep(520, 0.1);
  showToast('Stopwatch started');
}

function pauseTimer() {
  if (!state.activeTimer.isRunning) return;

  state.activeTimer.isRunning = false;
  clearInterval(state.activeTimer.intervalId);
  state.activeTimer.intervalId = null;

  updateTimerUI();
  playHapticBeep(440, 0.1);
  showToast('Stopwatch paused');
}

function resetTimer() {
  pauseTimer();
  state.activeTimer.elapsedSeconds = 0;
  updateTimerUI();
  showToast('Timer reset');
}

function tickTimer() {
  const now = Date.now();
  state.activeTimer.elapsedSeconds = Math.floor((now - state.activeTimer.startTime) / 1000);
  updateTimerUI();
}

function updateTimerUI() {
  const t = state.activeTimer;
  const timeFormatted = formatSecondsToHMS(t.elapsedSeconds);

  const liveClock = document.getElementById('liveTimerClock');
  const liveStatus = document.getElementById('liveTimerStatus');
  const playText = document.getElementById('timerPlayText');
  const playIcon = document.getElementById('timerPlayIcon');
  const liveProj = document.getElementById('liveTimerProjectName');
  const liveTask = document.getElementById('liveTimerTaskName');
  const ring = document.getElementById('timerProgressRing');

  if (liveClock) liveClock.textContent = timeFormatted;
  if (liveProj) liveProj.textContent = t.projectName;
  if (liveTask) liveTask.textContent = t.taskName || 'Active Task';

  if (liveStatus) {
    liveStatus.textContent = t.isRunning ? 'TRACKING TIME' : (t.elapsedSeconds > 0 ? 'PAUSED' : 'READY TO START');
  }

  if (playText && playIcon) {
    if (t.isRunning) {
      playText.textContent = 'Pause';
      playIcon.innerHTML = '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>';
    } else {
      playText.textContent = t.elapsedSeconds > 0 ? 'Resume' : 'Start';
      playIcon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"/>';
    }
  }

  if (ring) {
    const totalCirc = 590;
    const progress = (t.elapsedSeconds % 3600) / 3600;
    ring.style.strokeDashoffset = totalCirc - (progress * totalCirc);
  }

  const banner = document.getElementById('activeTimerBanner');
  const bannerVal = document.getElementById('bannerTimerVal');
  const tabDot = document.getElementById('timerTabActiveDot');

  if (banner && bannerVal) {
    if (t.isRunning || t.elapsedSeconds > 0) {
      banner.style.display = 'flex';
      bannerVal.textContent = timeFormatted;
      if (tabDot) tabDot.style.display = 'block';
    } else {
      banner.style.display = 'none';
      if (tabDot) tabDot.style.display = 'none';
    }
  }

  const inlineLabel = document.getElementById('timerInlineLabel');
  if (inlineLabel) {
    inlineLabel.textContent = t.isRunning ? 'Pause Timer' : 'Start Timer';
  }
}

function stopAndFillForm() {
  const elapsed = state.activeTimer.elapsedSeconds;
  pauseTimer();

  const hoursDecimal = Math.max(0.1, elapsed / 3600);
  const timeFormatted = decimalToTimeStr(hoursDecimal);

  const timeInput = document.getElementById('inputTimeSpent');
  if (timeInput) timeInput.value = timeFormatted;

  switchTab('viewLog');
  showToast(`Recorded ${timeFormatted} into Timesheet`);
}

// =========================================================
// 7. REALTIME SETTINGS TEST CONNECTION
// =========================================================
async function testOdooApiConnection() {
  const resultBox = document.getElementById('testConnectionResult');
  const url = document.getElementById('odooUrl').value.trim();
  const db = document.getElementById('odooDb').value.trim();
  const user = document.getElementById('odooUser').value.trim();
  const apiKey = document.getElementById('odooApiKey').value.trim();

  if (!resultBox) return;

  resultBox.style.display = 'block';
  resultBox.className = 'conn-result-box';
  resultBox.innerHTML = `<span>⏳ Authenticating directly with Odoo via XML-RPC...</span>`;

  try {
    const res = await fetch('/api/odoo/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, db, user, apiKey })
    });
    const data = await res.json();

    if (data.status === 'success') {
      resultBox.className = 'conn-result-box success';
      resultBox.innerHTML = `
        <strong>✓ Odoo Connected Successfully!</strong><br>
        UID: <code>#${data.uid}</code><br>
        Projects Found in Odoo: <strong>${data.projects_count}</strong><br>
        ${(data.projects || []).map(p => `• ${escapeHtml(p.name)} (ID #${p.id})`).join('<br>')}
      `;
      // Refresh local projects list
      state.projects = data.projects || state.projects;
      populateProjectDropdown();
      showToast('✓ Odoo connected & projects synced!');
    } else {
      resultBox.className = 'conn-result-box error';
      resultBox.innerHTML = `✕ Connection Error: ${escapeHtml(data.message)}`;
    }
  } catch (err) {
    resultBox.className = 'conn-result-box error';
    resultBox.innerHTML = `✕ Failed to reach local backend server: ${escapeHtml(err.message)}`;
  }
}

// =========================================================
// 8. TABS & CSV
// =========================================================
function exportTimesheetsCSV() {
  if (state.timesheets.length === 0) {
    showToast('No entries to export');
    return;
  }

  const headers = ['Date', 'Project', 'Task', 'Hours', 'Time (HH:MM)', 'Description'];
  const rows = state.timesheets.map(e => [
    `"${e.date}"`,
    `"${(e.project || '').replace(/"/g, '""')}"`,
    `"${(e.task || '').replace(/"/g, '""')}"`,
    e.hours,
    `"${e.formattedTime || decimalToTimeStr(e.hours)}"`,
    `"${(e.description || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `odoo_timesheets_${getTodayStr()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast('✓ Timesheets exported as CSV');
}

function switchTab(viewId) {
  state.currentView = viewId;

  document.querySelectorAll('.app-view').forEach(view => {
    if (view.id === viewId) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });

  document.querySelectorAll('.tab-item').forEach(btn => {
    if (btn.getAttribute('data-view') === viewId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  const scrollArea = document.getElementById('contentArea');
  if (scrollArea) scrollArea.scrollTop = 0;
}

// =========================================================
// 9. EVENT LISTENERS
// =========================================================
document.addEventListener('DOMContentLoaded', () => {
  const dateInput = document.getElementById('inputDate');
  if (dateInput) dateInput.value = getTodayStr();

  const timeInput = document.getElementById('inputTimeSpent');
  if (timeInput) timeInput.value = '01:00';

  fetchOdooInitData();
  renderTimesheets();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(err => console.log('SW Note:', err));
  }

  let deferredPrompt = null;
  const btnBannerInstall = document.getElementById('btnBannerInstall');
  const installModal = document.getElementById('installGuideModal');
  const btnCloseInstallModal = document.getElementById('btnCloseInstallModal');
  const btnGotItInstall = document.getElementById('btnGotItInstall');

  function handleInstallClick() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choice) => {
        if (choice.outcome === 'accepted') {
          const banner = document.getElementById('pwaInstallBanner');
          if (banner) banner.style.display = 'none';
        }
        deferredPrompt = null;
      });
    } else if (installModal) {
      installModal.showModal();
    }
  }

  if (btnBannerInstall) btnBannerInstall.addEventListener('click', handleInstallClick);
  if (btnCloseInstallModal && installModal) btnCloseInstallModal.addEventListener('click', () => installModal.close());
  if (btnGotItInstall && installModal) btnGotItInstall.addEventListener('click', () => installModal.close());

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const btn = document.getElementById('btnInstallApp');
    if (btn) {
      btn.style.display = 'inline-flex';
      btn.onclick = handleInstallClick;
    }
  });

  window.addEventListener('appinstalled', () => {
    showToast('✓ App successfully installed to Home Screen!');
    const banner = document.getElementById('pwaInstallBanner');
    if (banner) banner.style.display = 'none';
    const btn = document.getElementById('btnInstallApp');
    if (btn) btn.style.display = 'none';
  });

  function updateClock() {
    const clockEl = document.getElementById('deviceClock');
    if (clockEl) {
      const now = new Date();
      clockEl.textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    }
  }
  updateClock();
  setInterval(updateClock, 30000);

  document.querySelectorAll('.tab-item').forEach(tab => {
    tab.addEventListener('click', () => {
      switchTab(tab.getAttribute('data-view'));
    });
  });

  const selectProj = document.getElementById('selectProject');
  const projectModal = document.getElementById('newProjectModal');
  const btnOpenNewProjectModal = document.getElementById('btnOpenNewProjectModal');

  if (btnOpenNewProjectModal && projectModal) {
    btnOpenNewProjectModal.addEventListener('click', () => {
      projectModal.showModal();
      const inputCustomProj = document.getElementById('inputCustomProject');
      if (inputCustomProj) inputCustomProj.focus();
    });
  }

  if (selectProj) {
    selectProj.addEventListener('change', () => {
      if (selectProj.value === '__NEW__') {
        if (projectModal) projectModal.showModal();
      } else {
        updateBreadcrumb();
        populateTaskDropdown();
      }
    });
  }

  // Modal for Adding Project directly in Odoo
  const btnCloseModal = document.getElementById('btnCloseProjectModal');
  const btnCancelProj = document.getElementById('btnCancelProject');
  const btnConfirmProj = document.getElementById('btnConfirmProject');
  const inputCustomProj = document.getElementById('inputCustomProject');

  function closeCustomModal() {
    if (projectModal) projectModal.close();
    if (selectProj && selectProj.value === '__NEW__') {
      selectProj.value = state.projects[0] ? state.projects[0].id : 1;
      updateBreadcrumb();
    }
  }

  if (btnCloseModal) btnCloseModal.addEventListener('click', closeCustomModal);
  if (btnCancelProj) btnCancelProj.addEventListener('click', closeCustomModal);

  if (btnConfirmProj && inputCustomProj) {
    btnConfirmProj.addEventListener('click', async () => {
      const newName = inputCustomProj.value.trim();
      if (newName) {
        btnConfirmProj.disabled = true;
        btnConfirmProj.textContent = 'Creating...';
        await handleCreateOdooProject(newName);
        btnConfirmProj.disabled = false;
        btnConfirmProj.textContent = 'Add Project';
        inputCustomProj.value = '';
        if (projectModal) projectModal.close();
      }
    });
  }

  // Quick dates
  const chipToday = document.getElementById('chipToday');
  const chipYesterday = document.getElementById('chipYesterday');
  if (chipToday) {
    chipToday.addEventListener('click', () => {
      if (dateInput) dateInput.value = getTodayStr();
      chipToday.classList.add('active');
      if (chipYesterday) chipYesterday.classList.remove('active');
    });
  }
  if (chipYesterday) {
    chipYesterday.addEventListener('click', () => {
      if (dateInput) dateInput.value = getYesterdayStr();
      chipYesterday.classList.add('active');
      if (chipToday) chipToday.classList.remove('active');
    });
  }

  // Quick times
  document.querySelectorAll('.time-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const mins = parseInt(chip.getAttribute('data-mins'), 10);
      handleTimeChipAdd(mins);
    });
  });

  // Hashtags
  document.querySelectorAll('.tag-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const tag = chip.getAttribute('data-tag');
      handleTagChipAdd(tag);
    });
  });

  // Save Timesheet
  const btnSave = document.getElementById('btnSaveTimesheet');
  if (btnSave) btnSave.addEventListener('click', handleSaveTimesheet);

  // Clear Form
  const btnClear = document.getElementById('btnClearForm');
  const btnReset = document.getElementById('btnResetForm');
  function clearMainForm() {
    const taskInput = document.getElementById('inputTask');
    const timeInput = document.getElementById('inputTimeSpent');
    const activityInput = document.getElementById('inputActivity');
    if (taskInput) taskInput.value = '';
    if (timeInput) timeInput.value = '01:00';
    if (activityInput) activityInput.value = '';
    showToast('Form reset');
  }
  if (btnClear) btnClear.addEventListener('click', clearMainForm);
  if (btnReset) btnReset.addEventListener('click', clearMainForm);

  // Inline timer
  const btnInlineTimer = document.getElementById('btnToggleTimerInline');
  if (btnInlineTimer) {
    btnInlineTimer.addEventListener('click', () => {
      if (state.activeTimer.isRunning) pauseTimer();
      else startTimer();
    });
  }

  // Fullscreen stopwatch
  const btnTimerToggle = document.getElementById('btnTimerToggle');
  const btnTimerReset = document.getElementById('btnTimerReset');
  const btnTimerStop = document.getElementById('btnTimerStopAndLog');

  if (btnTimerToggle) {
    btnTimerToggle.addEventListener('click', () => {
      if (state.activeTimer.isRunning) pauseTimer();
      else startTimer();
    });
  }
  if (btnTimerReset) btnTimerReset.addEventListener('click', resetTimer);
  if (btnTimerStop) btnTimerStop.addEventListener('click', stopAndFillForm);

  // Banner
  const bannerPause = document.getElementById('bannerPauseBtn');
  const bannerStop = document.getElementById('bannerStopBtn');
  if (bannerPause) {
    bannerPause.addEventListener('click', () => {
      if (state.activeTimer.isRunning) {
        pauseTimer();
        bannerPause.textContent = 'Resume';
      } else {
        startTimer();
        bannerPause.textContent = 'Pause';
      }
    });
  }
  if (bannerStop) bannerStop.addEventListener('click', stopAndFillForm);

  // Top bar buttons
  const btnQuickNew = document.getElementById('btnQuickNew');
  if (btnQuickNew) {
    btnQuickNew.addEventListener('click', () => {
      clearMainForm();
      switchTab('viewLog');
      const taskInput = document.getElementById('inputTask');
      if (taskInput) taskInput.focus();
    });
  }

  const btnOpenSettings = document.getElementById('btnOpenSettings');
  const btnCloudSync = document.getElementById('btnCloudSync');
  const btnQuickRefresh = document.getElementById('btnQuickRefresh');
  const btnRefreshProjects = document.getElementById('btnRefreshProjects');

  if (btnOpenSettings) btnOpenSettings.addEventListener('click', () => switchTab('viewSettings'));
  if (btnCloudSync) btnCloudSync.addEventListener('click', () => fetchOdooInitData(true));
  if (btnQuickRefresh) btnQuickRefresh.addEventListener('click', () => fetchOdooInitData(true));
  if (btnRefreshProjects) btnRefreshProjects.addEventListener('click', () => fetchOdooInitData(true));

  // Automatically refresh live projects & tasks from Odoo every 5 seconds!
  setInterval(() => fetchOdooInitData(false), 5000);

  const btnJumpHistory = document.getElementById('btnJumpHistory');
  if (btnJumpHistory) btnJumpHistory.addEventListener('click', () => switchTab('viewHistory'));

  // History search
  const searchHistory = document.getElementById('searchHistory');
  const filterProject = document.getElementById('filterProject');
  if (searchHistory) searchHistory.addEventListener('input', renderHistoryView);
  if (filterProject) filterProject.addEventListener('change', renderHistoryView);

  // CSV
  const btnExport = document.getElementById('btnExportCSV');
  if (btnExport) btnExport.addEventListener('click', exportTimesheetsCSV);

  const btnClearAllHistory = document.getElementById('btnClearAllHistory');
  if (btnClearAllHistory) {
    btnClearAllHistory.addEventListener('click', () => {
      if (confirm('Clear local history logs?')) {
        state.timesheets = [];
        saveLocalTimesheets([]);
        renderTimesheets();
        showToast('Local history cleared');
      }
    });
  }

  // Toggle frame
  const btnToggleFrame = document.getElementById('btnToggleFrame');
  const simWrapper = document.getElementById('simWrapper');
  const frameBtnText = document.getElementById('frameBtnText');
  if (btnToggleFrame && simWrapper) {
    btnToggleFrame.addEventListener('click', () => {
      simWrapper.classList.toggle('full-width');
      if (frameBtnText) {
        frameBtnText.textContent = simWrapper.classList.contains('full-width') ? 'Phone Frame' : 'Full Width';
      }
    });
  }

  // Toggle theme
  const btnToggleTheme = document.getElementById('btnToggleTheme');
  const themeIcon = document.getElementById('themeIcon');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      document.body.classList.toggle('theme-light');
      if (themeIcon) {
        themeIcon.textContent = document.body.classList.contains('theme-light') ? '🌙' : '☀️';
      }
    });
  }

  // Real Odoo Test Connection Button
  const btnTestConn = document.getElementById('btnTestOdooConnection');
  if (btnTestConn) btnTestConn.addEventListener('click', testOdooApiConnection);

  const btnTogglePw = document.getElementById('btnTogglePw');
  const odooApiKey = document.getElementById('odooApiKey');
  if (btnTogglePw && odooApiKey) {
    btnTogglePw.addEventListener('click', () => {
      odooApiKey.type = odooApiKey.type === 'password' ? 'text' : 'password';
    });
  }
});
